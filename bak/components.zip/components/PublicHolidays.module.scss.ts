/* tslint:disable */
require("./PublicHolidays.module.css");
const styles = {
  publicHolidays: 'publicHolidays_b0255aa8',
  teams: 'teams_b0255aa8',
  container: 'container_b0255aa8',
  loading: 'loading_b0255aa8',
  spinner: 'spinner_b0255aa8',
  spin: 'spin_b0255aa8'
};

export default styles;
/* tslint:enable */