// import { useEffect, useState } from "react";
// import { HolidayCard } from "./HolidayCard";
// import { UpcomingHolidays } from "./UpcomingHolidays";
// import { useToast } from "@/components/ui/use-toast";
// import styles from "../styles/Index.module.scss";
// import * as React from "react";

// interface Holiday {
//   date: string;
//   name: string;
// }

// const Index = () => {
//   const [country, setCountry] = useState<string>("");
//   const [nextHoliday, setNextHoliday] = useState<Holiday | null>(null);
//   const [upcomingHolidays, setUpcomingHolidays] = useState<Holiday[]>([]);
//   const [loading, setLoading] = useState(true);
//   const { toast } = useToast();

//   useEffect(() => {
//     fetch("https://ipapi.co/json/")
//       .then((response) => response.json())
//       .then((data) => {
//         setCountry(data.country_name);
//         fetchHolidays(data.country_name);
//       })
//       .catch((error) => {
//         console.error("Error fetching location:", error);
//         toast({
//           title: "Error",
//           description: "Failed to detect your location. Using default country (US).",
//           variant: "destructive",
//         });
//         setCountry("US");
//         fetchHolidays("US");
//       });
//   }, []);

//   const fetchHolidays = async (countryCode: string) => {
//     try {
//         this._Service.getUpcomingPublicHolidays(listGUID, limitToDate, currentLocation, 1)
//       const year = new Date().getFullYear();
//       const response = await fetch(
//         `https://date.nager.at/api/v3/PublicHolidays/${year}/${countryCode}`
//       );
//       const holidays = await response.json();
      
//       const futureHolidays = holidays.filter(
//         (holiday: Holiday) => new Date(holiday.date) > new Date()
//       );

//       if (futureHolidays.length > 0) {
//         setNextHoliday(futureHolidays[0]);
//         setUpcomingHolidays(futureHolidays.slice(1, 5));
//       }
//     } catch (error) {
//       console.error("Error fetching holidays:", error);
//       toast({
//         title: "Error",
//         description: "Failed to fetch holidays. Please try again later.",
//         variant: "destructive",
//       });
//     } finally {
//       setLoading(false);
//     }
//   };

//   if (loading) {
//     return (
//       <div className={styles.loading}>
//         <div className={styles.spinner}></div>
//       </div>
//     );
//   }

//   return (
//     <div className={styles.container}>
//       {nextHoliday && <HolidayCard {...nextHoliday} />}
//       {upcomingHolidays.length > 0 && (
//         <UpcomingHolidays holidays={upcomingHolidays} />
//       )}
//     </div>
//   );
// };

// export default Index;