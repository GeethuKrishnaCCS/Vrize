/* tslint:disable */
require("./HolidayCard.module.css");
const styles = {
  card: 'card_b8f0a554',
  cardContent: 'cardContent_b8f0a554',
  dateSection: 'dateSection_b8f0a554',
  day: 'day_b8f0a554',
  monthYear: 'monthYear_b8f0a554',
  holidayName: 'holidayName_b8f0a554',
  icon: 'icon_b8f0a554'
};

export default styles;
/* tslint:enable */