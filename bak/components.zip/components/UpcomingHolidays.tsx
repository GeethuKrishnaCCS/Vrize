// import { Calendar } from "lucide-react";
import * as React from "react";
import styles from "./UpcomingHolidays.module.scss";
import { IPublicHoliday } from "../../../shared/services/publicHolidaysService";


interface UpcomingHolidaysProps {
    holidays: IPublicHoliday[];
}

export const UpcomingHolidays = ({ holidays }: UpcomingHolidaysProps) => {
    return (
        <div className={styles.container}>
            <h3 className={styles.title}>Upcoming Holidays</h3>
            {holidays.map((holiday, index) => (
                <div key={index} className={styles.holidayItem}>
                    {/* <Calendar className={styles.icon} /> */}
                    <img src={"Calendar"} />
                    <div className={styles.holidayInfo}>
                        <div className={styles.holidayName}>{holiday.Title}</div>
                        <div className={styles.holidayDate}>
                            {(holiday.Date).toLocaleDateString('default', {
                                weekday: 'long',
                                day: 'numeric',
                                month: 'long',
                                year: 'numeric'
                            })}
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};