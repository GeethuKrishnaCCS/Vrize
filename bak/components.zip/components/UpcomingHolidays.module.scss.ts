/* tslint:disable */
require("./UpcomingHolidays.module.css");
const styles = {
  container: 'container_f877137c',
  title: 'title_f877137c',
  holidayItem: 'holidayItem_f877137c',
  icon: 'icon_f877137c',
  holidayInfo: 'holidayInfo_f877137c',
  holidayName: 'holidayName_f877137c',
  holidayDate: 'holidayDate_f877137c'
};

export default styles;
/* tslint:enable */