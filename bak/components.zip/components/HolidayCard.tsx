import styles from "./HolidayCard.module.scss";
import * as React from "react";

interface HolidayCardProps {
    Date: Date;
    Title: string;
}

export const HolidayCard = ({ Date, Title }: HolidayCardProps) => {
    const holidayDate = Date;

    return (
        <div className={styles.card}>
            <div className={styles.cardContent}>
                <div className={styles.dateSection}>
                    <div className={styles.day}>
                        {holidayDate.getDate()}
                    </div>
                    <div className={styles.monthYear}>
                        {holidayDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
                    </div>
                    <h2 className={styles.holidayName}>{Title}</h2>
                </div>
                <div className={styles.icon}>
                    <img src={"../assets/icon-bold-arrow-up.svg"} />
                </div>
            </div>
        </div>
    );
};
