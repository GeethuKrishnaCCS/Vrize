/* tslint:disable */
require("./HolidayCard.module.css");
const styles = {
  card: 'card_f181bf0d',
  cardContent: 'cardContent_f181bf0d',
  dateSection: 'dateSection_f181bf0d',
  day: 'day_f181bf0d',
  monthYear: 'monthYear_f181bf0d',
  holidayName: 'holidayName_f181bf0d',
  icon: 'icon_f181bf0d'
};

export default styles;
/* tslint:enable */