/* tslint:disable */
require("./PublicHolidays.module.css");
const styles = {
  publicHolidays: 'publicHolidays_5d411a3e',
  teams: 'teams_5d411a3e',
  container: 'container_5d411a3e',
  loading: 'loading_5d411a3e',
  spinner: 'spinner_5d411a3e',
  spin: 'spin_5d411a3e'
};

export default styles;
/* tslint:enable */