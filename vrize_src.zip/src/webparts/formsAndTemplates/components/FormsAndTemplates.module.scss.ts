/* tslint:disable */
require("./FormsAndTemplates.module.css");
const styles = {
  formsAndTemplates: 'formsAndTemplates_8acb1e51',
  divrow: 'divrow_8acb1e51',
  h1: 'h1_8acb1e51',
  card: 'card_8acb1e51',
  cardfooter: 'cardfooter_8acb1e51',
  description: 'description_8acb1e51',
  pendingStatus: 'pendingStatus_8acb1e51',
  submitStatus: 'submitStatus_8acb1e51',
  date: 'date_8acb1e51',
  button: 'button_8acb1e51',
  btnprimary: 'btnprimary_8acb1e51',
  pagetitle: 'pagetitle_8acb1e51'
};

export default styles;
/* tslint:enable */