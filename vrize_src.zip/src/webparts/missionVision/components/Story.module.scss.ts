/* tslint:disable */
require("./Story.module.css");
const styles = {
  storySection: 'storySection_99236974',
  imageContainer: 'imageContainer_99236974',
  textContent: 'textContent_99236974',
  storyTitle: 'storyTitle_99236974',
  storyImage: 'storyImage_99236974',
  storyParagraph: 'storyParagraph_99236974'
};

export default styles;
/* tslint:enable */