/* tslint:disable */
require("./CoreValues.module.css");
const styles = {
  section: 'section_32ddcad5',
  container: 'container_32ddcad5',
  grid: 'grid_32ddcad5',
  content: 'content_32ddcad5',
  title: 'title_32ddcad5',
  text: 'text_32ddcad5',
  valuesList: 'valuesList_32ddcad5',
  valueItem: 'valueItem_32ddcad5',
  fadeIn: 'fadeIn_32ddcad5',
  letter: 'letter_32ddcad5',
  valueContent: 'valueContent_32ddcad5',
  valueTitle: 'valueTitle_32ddcad5',
  valueDescription: 'valueDescription_32ddcad5',
  imageWrapper: 'imageWrapper_32ddcad5',
  image: 'image_32ddcad5'
};

export default styles;
/* tslint:enable */