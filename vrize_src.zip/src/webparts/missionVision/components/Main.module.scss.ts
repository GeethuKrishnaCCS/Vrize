/* tslint:disable */
require("./Main.module.css");
const styles = {
  missionVision: 'missionVision_2a997ef3',
  teams: 'teams_2a997ef3',
  welcome: 'welcome_2a997ef3',
  welcomeImage: 'welcomeImage_2a997ef3',
  links: 'links_2a997ef3'
};

export default styles;
/* tslint:enable */