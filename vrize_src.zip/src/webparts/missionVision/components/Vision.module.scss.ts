/* tslint:disable */
require("./Vision.module.css");
const styles = {
  section: 'section_e7045920',
  container: 'container_e7045920',
  imageWrapper: 'imageWrapper_e7045920',
  image: 'image_e7045920',
  contentContainer: 'contentContainer_e7045920',
  title: 'title_e7045920',
  grid: 'grid_e7045920',
  card: 'card_e7045920',
  fadeIn: 'fadeIn_e7045920',
  icon: 'icon_e7045920',
  label: 'label_e7045920'
};

export default styles;
/* tslint:enable */