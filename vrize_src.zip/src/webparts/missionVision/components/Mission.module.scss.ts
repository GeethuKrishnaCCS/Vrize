/* tslint:disable */
require("./Mission.module.css");
const styles = {
  section: 'section_75e6a22e',
  container: 'container_75e6a22e',
  grid: 'grid_75e6a22e',
  content: 'content_75e6a22e',
  fadeIn: 'fadeIn_75e6a22e',
  title: 'title_75e6a22e',
  subtitle: 'subtitle_75e6a22e',
  text: 'text_75e6a22e',
  imageWrapper: 'imageWrapper_75e6a22e',
  image: 'image_75e6a22e',
  circle: 'circle_75e6a22e'
};

export default styles;
/* tslint:enable */