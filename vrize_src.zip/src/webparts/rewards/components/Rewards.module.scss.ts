/* tslint:disable */
require("./Rewards.module.css");
const styles = {
  rewards: 'rewards_ebc15c1a',
  StackStyle: 'StackStyle_ebc15c1a',
  StackStyleContainer: 'StackStyleContainer_ebc15c1a',
  heading: 'heading_ebc15c1a',
  pagetitle: 'pagetitle_ebc15c1a',
  title: 'title_ebc15c1a',
  seeall: 'seeall_ebc15c1a',
  link: 'link_ebc15c1a',
  BirthdaySlider: 'BirthdaySlider_ebc15c1a',
  Prevbtn: 'Prevbtn_ebc15c1a',
  Nextbtn: 'Nextbtn_ebc15c1a',
  card: 'card_ebc15c1a',
  date: 'date_ebc15c1a',
  imgWidth: 'imgWidth_ebc15c1a',
  name: 'name_ebc15c1a',
  designation: 'designation_ebc15c1a',
  uploadarea: 'uploadarea_ebc15c1a',
  BirthdayCard: 'BirthdayCard_ebc15c1a',
  NavigationLeftButtonStyling: 'NavigationLeftButtonStyling_ebc15c1a',
  NavigationRightButtonStyling: 'NavigationRightButtonStyling_ebc15c1a',
  NavDot: 'NavDot_ebc15c1a',
  Dot: 'Dot_ebc15c1a',
  InnerDot: 'InnerDot_ebc15c1a',
  active: 'active_ebc15c1a'
};

export default styles;
/* tslint:enable */