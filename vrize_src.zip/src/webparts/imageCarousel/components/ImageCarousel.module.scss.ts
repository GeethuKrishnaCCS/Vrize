/* tslint:disable */
require("./ImageCarousel.module.css");
const styles = {
  imageCarousel: 'imageCarousel_f5069c22',
  container: 'container_f5069c22',
  center: 'center_f5069c22',
  pagetitle: 'pagetitle_f5069c22'
};

export default styles;
/* tslint:enable */