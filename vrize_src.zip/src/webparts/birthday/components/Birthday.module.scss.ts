/* tslint:disable */
require("./Birthday.module.css");
const styles = {
  birthday: 'birthday_aa45aeba',
  StackStyle: 'StackStyle_aa45aeba',
  StackStyleContainer: 'StackStyleContainer_aa45aeba',
  heading: 'heading_aa45aeba',
  pagetitle: 'pagetitle_aa45aeba',
  title: 'title_aa45aeba',
  seeall: 'seeall_aa45aeba',
  link: 'link_aa45aeba',
  BirthdaySlider: 'BirthdaySlider_aa45aeba',
  Prevbtn: 'Prevbtn_aa45aeba',
  Nextbtn: 'Nextbtn_aa45aeba',
  card: 'card_aa45aeba',
  date: 'date_aa45aeba',
  imgWidth: 'imgWidth_aa45aeba',
  name: 'name_aa45aeba',
  designation: 'designation_aa45aeba',
  uploadarea: 'uploadarea_aa45aeba',
  BirthdayCard: 'BirthdayCard_aa45aeba',
  NavigationLeftButtonStyling: 'NavigationLeftButtonStyling_aa45aeba',
  NavigationRightButtonStyling: 'NavigationRightButtonStyling_aa45aeba',
  NavDot: 'NavDot_aa45aeba',
  Dot: 'Dot_aa45aeba',
  InnerDot: 'InnerDot_aa45aeba',
  active: 'active_aa45aeba'
};

export default styles;
/* tslint:enable */