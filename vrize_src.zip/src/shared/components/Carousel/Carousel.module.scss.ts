/* tslint:disable */
require("./Carousel.module.css");
const styles = {
  carousel: 'carousel_8159f70c',
  mySlides: 'mySlides_8159f70c',
  show: 'show_8159f70c',
  hide: 'hide_8159f70c',
  slideshowContainer: 'slideshowContainer_8159f70c',
  imgWidth: 'imgWidth_8159f70c',
  sectionimgWidth: 'sectionimgWidth_8159f70c',
  prev: 'prev_8159f70c',
  next: 'next_8159f70c',
  backgroundBlack: 'backgroundBlack_8159f70c',
  text: 'text_8159f70c',
  numbertext: 'numbertext_8159f70c',
  dot: 'dot_8159f70c',
  active: 'active_8159f70c',
  fade: 'fade_8159f70c'
};

export default styles;
/* tslint:enable */